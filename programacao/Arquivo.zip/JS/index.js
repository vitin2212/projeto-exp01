const PI = 3.14;

const circulo = (
    raio: 3, 
    area: function () {
        return this.raio * this.raio * PI;
    },
    perimetro: function(){
        return 2*PI*this.raio;
    }
);

console.log(circulo.perimetro);